# flake8: noqa

from .service import create_finetuned_model, create_vector_embeddings

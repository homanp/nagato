from .nagato import ingest
